#ifndef ARMA_MSSM_H
#define ARMA_MSSM_H

#ifndef ROLL_DEBUG
#define ARMA_NO_DEBUG
#endif

#include <RcppArmadillo.h>

#endif
