# override defaults
formals(expect_known_output)$update <- formals(expect_known_value)$update <-
  FALSE
