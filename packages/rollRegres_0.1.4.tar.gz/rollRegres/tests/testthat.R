library(testthat)
library(rollRegres)

test_check("rollRegres")
